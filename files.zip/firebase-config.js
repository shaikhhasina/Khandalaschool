/* ============================================================
   FIREBASE CONFIGURATION - PM SHRI Kendrashala Khandala
   ------------------------------------------------------------
   1. Go to https://console.firebase.google.com/
   2. Create a project (e.g. "khandala-school-site")
   3. Click the "</>" (Web) icon to register a web app
   4. Copy the config object Firebase gives you and paste the
      values below, replacing the placeholders.
   5. In the Firebase Console, enable:
        - Authentication > Sign-in method > Email/Password
          (this is how staff will log in to the dashboard)
        - Firestore Database > Create database (start in test
          mode for development, then apply firestore.rules
          before going live)
   ============================================================ */

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db = firebase.firestore();
